# OpenText: Open-Source Text Social Media Application

A lightweight, secure, and privacy-first text-only social media platform built for Android. OpenText avoids rich-media database overhead while prioritizing speed, ease of use, and local state isolation.

---

## 🛠️ TECH STACK

- **Frontend:** Android Studio with Jetpack Compose (Kotlin), Material 3, Navigation Compose, DataStore, and Retrofit.
- **Backend:** Supabase PostgreSQL Database, Supabase Auth (JWT-based), and Supabase Realtime for instant messaging.
- **Security & Spam Protection:** Upstash Redis rate-limiting (max 10 posts/hour per user), hCaptcha puzzle solving, and HTTPS-enforced OkHttp clients.

---

## 💾 1. SUPABASE DATABASE SCHEMA (SQL)

Run the following DDL script in your Supabase SQL editor to create all the essential tables, primary keys, relationships, and performance indexes.

```sql
-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- 1. PROFILES TABLE
create table public.profiles (
    id uuid references auth.users on delete cascade primary key,
    username text unique not null,
    email text unique not null,
    display_name text,
    bio text,
    avatar_color text not null default '#FF5722',
    is_private boolean default false,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 2. POSTS TABLE
create table public.posts (
    id uuid default uuid_generate_v4() primary key,
    user_id uuid references public.profiles(id) on delete cascade not null,
    username text not null,
    text text not null check (char_length(text) <= 500),
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    likes_count integer default 0 not null,
    comments_count integer default 0 not null
);

-- 3. STORIES TABLE
create table public.stories (
    id uuid default uuid_generate_v4() primary key,
    user_id uuid references public.profiles(id) on delete cascade not null,
    username text not null,
    avatar_color text not null,
    text text not null check (char_length(text) <= 280),
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    expires_at timestamp with time zone not null
);

-- 4. STORY VIEWS TABLE
create table public.story_views (
    id uuid default uuid_generate_v4() primary key,
    story_id uuid references public.stories(id) on delete cascade not null,
    viewer_username text not null,
    viewed_at timestamp with time zone default timezone('utc'::text, now()) not null,
    unique(story_id, viewer_username)
);

-- 5. COMMENTS TABLE
create table public.comments (
    id uuid default uuid_generate_v4() primary key,
    post_id uuid references public.posts(id) on delete cascade not null,
    user_id uuid references public.profiles(id) on delete cascade not null,
    username text not null,
    avatar_color text not null,
    text text not null,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 6. LIKES TABLE
create table public.likes (
    id uuid default uuid_generate_v4() primary key,
    post_id uuid references public.posts(id) on delete cascade not null,
    user_id uuid references public.profiles(id) on delete cascade not null,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    unique(post_id, user_id)
);

-- 7. FOLLOWS TABLE
create table public.follows (
    id uuid default uuid_generate_v4() primary key,
    follower_id uuid references public.profiles(id) on delete cascade not null,
    following_id uuid references public.profiles(id) on delete cascade not null,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    unique(follower_id, following_id)
);

-- 8. MESSAGES TABLE
create table public.messages (
    id uuid default uuid_generate_v4() primary key,
    sender_id uuid references public.profiles(id) on delete cascade not null,
    receiver_id uuid references public.profiles(id) on delete cascade not null,
    text text not null,
    is_read boolean default false not null,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 9. NOTIFICATIONS TABLE
create table public.notifications (
    id uuid default uuid_generate_v4() primary key,
    target_user_id uuid references public.profiles(id) on delete cascade not null,
    type text not null, -- LIKE, COMMENT, FOLLOW, MENTION
    sender_username text not null,
    sender_avatar_color text not null,
    text text not null,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- PERFORMANCE INDEXES
create index idx_posts_created_at on public.posts(created_at desc);
create index idx_messages_sender_receiver on public.messages(sender_id, receiver_id);
create index idx_stories_expires_at on public.stories(expires_at);
create index idx_likes_post_id on public.likes(post_id);
create index idx_comments_post_id on public.comments(post_id);
```

---

## 🔒 2. SUPABASE RLS (ROW LEVEL SECURITY) POLICIES

To secure client queries, enforce Row Level Security. Ensure only authenticated users can write content or view private threads.

```sql
-- Enable RLS on all tables
alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.comments enable row level security;
alter table public.likes enable row level security;
alter table public.follows enable row level security;
alter table public.messages enable row level security;

-- PROFILES: Users can read all profiles; only owners can update theirs
create policy "Allow public profile reading" on public.profiles for select using (true);
create policy "Allow owners to edit profile" on public.profiles for update using (auth.uid() = id);

-- POSTS: Users can read public posts; only owners can delete or edit
create policy "Allow public reading of posts" on public.posts for select using (true);
create policy "Allow authenticated creation of posts" on public.posts for insert with check (auth.role() = 'authenticated');
create policy "Allow owner deletion of posts" on public.posts for delete using (auth.uid() = user_id);

-- DMs (MESSAGES): Users can only read messages sent to or by them
create policy "Allow DM thread selective read" on public.messages for select 
    using (auth.uid() = sender_id or auth.uid() = receiver_id);
create policy "Allow DM insertion" on public.messages for insert 
    with check (auth.uid() = sender_id);
```

---

## 📡 3. BACKEND REST API ENDPOINTS

The Android Retrofit interfaces communicate with the Supabase API via standard REST endpoints:

- **Auth endpoints:**
  - `POST /auth/v1/signup` (Creates user credential in Supabase Auth GoTrue service)
  - `POST /auth/v1/token?grant_type=password` (Authenticates and returns JWT)
- **Database Postgrest CRUD endpoints:**
  - `GET /rest/v1/posts` (Queries active posts feed)
  - `POST /rest/v1/posts` (Creates post up to 500 characters)
  - `GET /rest/v1/profiles?id=eq.{id}` (Queries user profile details)
  - `PATCH /rest/v1/profiles?id=eq.{id}` (Updates bio & display name details)
  - `GET /rest/v1/messages` (Fetches 1-on-1 private DM thread selectively)
  - `POST /rest/v1/messages` (Appends new private messaging bubble)

---

## 📂 4. PROJECT FOLDER STRUCTURE

OpenText strictly implements a **Clean Architecture + MVVM** modular pattern:

```text
com.example/
│
├── data/
│   ├── api/                      # SupabaseApiService.kt, SupabaseClient.kt
│   ├── local/                    # EncryptedPreferencesManager.kt (for JWT)
│   ├── model/                    # Dtos.kt (API Request & Response transfer objects)
│   └── repository/               # RepositoryImpls.kt (Auth, Posts, Stories, DMs repositories)
│
├── domain/
│   ├── model/                    # Models.kt (User, Post, Story, Comment, Message entities)
│   └── repository/               # Interfaces.kt (Declarative interfaces for domain contracts)
│
├── presentation/
│   ├── components/               # LinkTextComponent.kt, UserAvatarComponent.kt
│   ├── navigation/               # Routes.kt, AppNavGraph.kt (Jetpack NavHost system)
│   └── screens/                  # SplashScreen, LoginScreen, RegisterScreen, HomeScreen, CreatePostScreen,
│                                 # PostDetailScreen, StoryScreen, CreateStoryScreen, ProfileScreen,
│                                 # EditProfileScreen, DMListScreen, DMChatScreen, NotificationScreen,
│                                 # SearchScreen, SettingsScreen
│
└── di/
    └── ServiceLocator.kt         # Fully automated DI service locator container
```

---

## 🛡️ 5. ANTI-SPAM & SECURITY FEATURES

1. **Upstash Redis Rate-Limiting:** Intercepts REST calls on the custom API gateway to enforce limit rules (e.g., max 10 posts/hour per user and max 5 register requests/IP per day).
2. **Interactive Captcha:** Embodies an in-app fruits verification puzzle during sign-up to block bot registrations.
3. **Transport Security:** Custom OkHttp clients have `usesCleartextTraffic=false` activated, rejecting insecure HTTP communication and enforcing HTTPS.
4. **Encrypted Storage:** Access tokens (JWT) are securely encrypted locally inside standard Android `EncryptedSharedPreferences`.
